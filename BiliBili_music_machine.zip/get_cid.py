from get_music import get_music_url

from requests import get


def get_bili_cid(bv):
    # 获得cid
    name_url = "https://api.bilibili.com/x/web-interface/view"
    get_url = "https://api.bilibili.com/x/player/pagelist"

    param = {
        "bvid": bv
    }

    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
        "referer": "https://www.bilibili.com"
    }
    # 获得cid

    new_get = get(url=get_url, params=param, headers=headers).json()
    # print(new_get)
    # 提取cid
    for data in new_get["data"]:
        cid = data["cid"]

    # 获得视频名字
    name_get = get(url=name_url, params=param, headers=headers).json()
    data = name_get["data"]
    name = data["title"]

    # print(cid)
    get_music_url(cid=cid, bv=bv, name=name)
    print(new_get)
    return bv
