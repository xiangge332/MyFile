from requests import get
from os import getenv


# import os


def get_music_download(url, bv, name):
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
        "referer": "https://www.bilibili.com/video/" + bv,

    }

    download = get(url=url, headers=headers, verify=True)

    # 寻找地址
    HOMEPATH = getenv("HOMEPATH")
    # 创造文件
    # os.mknod("./aideo/" + bv + ".mp4")  # windows无效
    # 保存
    with open(HOMEPATH + "\\Music\\" + name + ".mp3", "wb") as f:
        f.write(download.content)
    print(bv, "下载完成，文件在" + HOMEPATH + "\\Music\\" + name + ".mp3")
