from get_cid import get_bili_cid
from time import sleep
from os import system, getenv

while True:
    print("___________bilibili音乐下载器___________")
    do = input("_______________\n"
               "|1.搜索&下载    |\n"
               "|2.使用教程     |\n"
               "|3.下载路径     |\n"
               "|4.退出程序     |\n"
               "|(请输入数字编号)|\n"
               "_______________\n")
    if do == "1":
        bv = input("请输入Bv(退出请输入0):\n")
        if bv == "0":
            print("    ")
        else:
            get_bili_cid(bv)
    elif do == "2":
        print("请记下你要下载的BV号，但不要删除“BV”两字，然后选择1下载，他会下载到 C:\\Users\\[用户名]\\Music 下,"
              "如果报错关闭窗口，请检查网络情况，然后停止下载至少1小时（？）若仍然不行请联系作者")
    elif do == "4":
        print("正在退出程序中...")
        sleep(2)
        print("再见")
        sleep(1)
        break
    elif do == "3":
        HOMEPATH = getenv("HOMEPATH")
        Music = HOMEPATH + "\\Music"
        system("start explorer " + Music)
    else:
        print("请输入正确的数字")
