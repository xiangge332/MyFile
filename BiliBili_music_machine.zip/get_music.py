from requests import get
from get_music_download import get_music_download


def get_music_url(cid, bv, name):
    url = "http://api.bilibili.com/x/player/playurl"

    param = {
        "bvid": bv,
        # 详细请看 https://github.com/SocialSisterYi/bilibili-API-collect/blob/master/video/videostream_url.md
        "cid": cid,
        "qn": "16",
        "fnval": "16",
        "fnver": "0",
        "fourk": "0"
    }

    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
        "referer": "https://www.bilibili.com",

    }
    # 请求下载地址

    new_get = get(url=url, params=param, headers=headers).json()

    # print(new_get)
    # 找地址
    data = new_get["data"]
    dash = data["dash"]
    # print(dash)
    audio = dash["audio"]
    # print(audio)
    backup_url = audio[0]["base_url"]
    # backup_url = backup_url[1]
    # print(backup_url)

    get_music_download(backup_url, bv, name)
